export type MealType="BREAKFAST"|"LUNCH"|"DINNER";
export type MealAvailability="AVAILABLE"|"UNAVAILABLE";
export type PaymentMethod="BKASH"|"NAGAD"|"ROCKET"|"CASH";
export type PaymentStatus="UNPAID"|"ONLINE_PENDING"|"CASH_PENDING"|"PAID"|"FAILED";
export interface Meal{ id:string; type:MealType; items:string[]; time:string; price:number; availability:MealAvailability }
export interface Payment{ id:string; transactionId:string; billingPeriod:string; paymentDate:string; amount:number; paymentMethod:PaymentMethod; status:"PAID"; studentName:string; studentId:string; department:string; mealCount:number }
export interface OnlineRequest{ id:string; method:Exclude<PaymentMethod,"CASH">; amount:number; submittedAt:string; status:"ONLINE_PENDING"|"PAID"|"REJECTED"; transactionReference:string }
export interface CashRequest{ id:string; amount:number; submittedAt:string; status:"CASH_PENDING"|"PAID"|"REJECTED"; note:string }
