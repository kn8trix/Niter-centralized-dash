"use client";
import {createContext,useContext,useEffect,useMemo,useState} from "react";
import {CashRequest,OnlineRequest,Payment,PaymentMethod,PaymentStatus} from "@/types/meal";
import {initialPayments,monthlyBill} from "@/data/meal";
type Store={status:PaymentStatus;payments:Payment[];cashRequest:CashRequest|null;onlineRequest:OnlineRequest|null};
interface Ctx extends Store{openOnline:(method:Exclude<PaymentMethod,"CASH">)=>void;submitOnline:(method:Exclude<PaymentMethod,"CASH">,reference:string)=>void;submitCash:(note:string)=>void;verifyPayment:(kind:"cash"|"online")=>void;resetDemo:()=>void}
const C=createContext<Ctx|null>(null); const KEY="campus-meal-payment-v1";
export function MealProvider({children}:{children:React.ReactNode}){const [store,setStore]=useState<Store>({status:"UNPAID",payments:initialPayments,cashRequest:null,onlineRequest:null}); const [ready,setReady]=useState(false);
useEffect(()=>{try{const raw=localStorage.getItem(KEY);if(raw)setStore(JSON.parse(raw));}finally{setReady(true)}},[]);
useEffect(()=>{if(ready)localStorage.setItem(KEY,JSON.stringify(store))},[store,ready]);
function openOnline(method:Exclude<PaymentMethod,"CASH">){const urls={BKASH:"https://www.bkash.com/",NAGAD:"https://nagad.com.bd/",ROCKET:"https://www.dutchbanglabank.com/rocket/"};window.open(urls[method],"_blank","noopener,noreferrer")}
function submitOnline(method:Exclude<PaymentMethod,"CASH">,reference:string){setStore(s=>({...s,status:"ONLINE_PENDING",onlineRequest:{id:`ON-${Date.now()}`,method,amount:monthlyBill.amount,submittedAt:new Date().toLocaleString(),status:"ONLINE_PENDING",transactionReference:reference}}))}
function submitCash(note:string){setStore(s=>({...s,status:"CASH_PENDING",cashRequest:{id:`CASH-${Date.now()}`,amount:monthlyBill.amount,submittedAt:new Date().toLocaleString(),status:"CASH_PENDING",note}}))}
function verifyPayment(kind:"cash"|"online"){setStore(s=>{const req=kind==="cash"?s.cashRequest:s.onlineRequest;if(!req)return s;const payment:Payment={id:`PAY-${Date.now()}`,transactionId:`TXN-${Date.now().toString().slice(-8)}`,billingPeriod:monthlyBill.billingPeriod,paymentDate:new Date().toLocaleString(),amount:monthlyBill.amount,paymentMethod:kind==="cash"?"CASH":req.method,status:"PAID",studentName:"Demo Student",studentId:"CSE-2026-001",department:"CSE",mealCount:monthlyBill.mealCount};return {...s,status:"PAID",payments:[payment,...s.payments],cashRequest:kind==="cash"?null:s.cashRequest,onlineRequest:kind==="online"?null:s.onlineRequest}})}
function resetDemo(){setStore({status:"UNPAID",payments:[],cashRequest:null,onlineRequest:null})}
const value=useMemo(()=>({...store,openOnline,submitOnline,submitCash,verifyPayment,resetDemo}),[store]); return <C.Provider value={value}>{children}</C.Provider>}
export function useMeal(){const v=useContext(C);if(!v)throw Error("useMeal must be inside MealProvider");return v}
