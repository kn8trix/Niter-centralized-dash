# Campus Meal System

Complete Next.js + TypeScript + Tailwind prototype for the student meal system.

## Sequence
1. Student opens Meal Overview.
2. Student checks Menu.
3. Student checks Timing.
4. Student checks Weekly Schedule.
5. Student sees Coupon locked until payment.
6. Student opens Payment.
7. Student must pay before meal access.
8. Payment methods: bKash, Nagad, Rocket, Cash Payment.
9. bKash/Nagad/Rocket open the external payment service in a new tab.
10. Student submits the transaction/reference for verification.
11. Cash payment creates a pending cash request.
12. Admin verifies the submitted payment.
13. Only after verification does status become PAID.
14. Meal coupon becomes ACTIVE and payment history is updated.

## Important
The online links in `lib/payment-methods.ts` are service home/payment destinations for the prototype. A production university deployment should replace them with the university's actual merchant/payment gateway URLs and server-side webhook/API verification. Never mark an online payment PAID solely because a student clicked a link or entered a reference.

## Run
npm install
npm run dev

Student: /student/meal
Admin demo: /admin/meal
