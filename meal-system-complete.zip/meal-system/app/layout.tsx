import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata={title:"Campus Meal System",description:"Student meal planning and payment system"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
