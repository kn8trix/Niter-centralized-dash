import Sidebar from "@/components/meal/sidebar";import {MealProvider} from "@/components/meal/meal-provider";
export default function Layout({children}:{children:React.ReactNode}){return <MealProvider><div className="min-h-screen lg:flex"><Sidebar/><main className="flex-1 min-w-0"><div className="max-w-7xl mx-auto p-5 sm:p-8">{children}</div></main></div></MealProvider>}
