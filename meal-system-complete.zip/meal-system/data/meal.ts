import { Meal, Payment } from "@/types/meal";
export const meals:Meal[]=[
{id:"b1",type:"BREAKFAST",items:["Paratha","Egg","Tea"],time:"7:30 AM – 9:00 AM",price:50,availability:"AVAILABLE"},
{id:"l1",type:"LUNCH",items:["Rice","Chicken","Dal","Vegetable"],time:"12:30 PM – 2:00 PM",price:100,availability:"AVAILABLE"},
{id:"d1",type:"DINNER",items:["Rice","Fish","Dal","Vegetable"],time:"7:30 PM – 9:00 PM",price:90,availability:"AVAILABLE"}
];
export const monthlyBill={billingPeriod:"August 2026",mealCount:30,amount:1500};
export const initialPayments:Payment[]=[];
export const mealCoupon={id:"MC-2026-0810-001",mealType:"Monthly Meal Plan",date:"August 2026",status:"NOT ACTIVE",validUntil:"31 Aug 2026"};
