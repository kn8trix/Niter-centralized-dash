import { PaymentMethod } from "@/types/meal";
export const PAYMENT_LINKS:Record<Exclude<PaymentMethod,"CASH">,string>={
 BKASH:"https://www.bkash.com/",
 NAGAD:"https://nagad.com.bd/",
 ROCKET:"https://www.dutchbanglabank.com/rocket/"
};
export const paymentMethodLabel:Record<PaymentMethod,string>={BKASH:"bKash",NAGAD:"Nagad",ROCKET:"Rocket",CASH:"Cash Payment"};
